package com.example.hamadaa.mymovieapp;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.hamadaa.mymovieapp.Data.Movie;

import java.util.ArrayList;

public class MyDataBase {

    static final String    DATABASE_NAME = "MOVIES.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_NAME = "MOVIE";
    public static final String ID ="id";
    public static final String TITLE = "title";
    public static final String POSTER_IMAGE = "poster_image";
    public static final String OVERVIEW = "overview";
    public static final String RATE = "rating";
    public static final String DATE = "date";
    private final Context context;

    SQLiteDatabase database;
    Helper helper;



    public MyDataBase
            (Context c)
    {
        this.context=c;
    }

    public  class Helper extends SQLiteOpenHelper
    {

        public Helper(Context context)
        {

            super(context, DATABASE_NAME, null, DATABASE_VERSION);

        }


        public void onCreate(SQLiteDatabase db)
        {
            final String SQL_CREATE_MOVIE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" +
                    ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    TITLE + " TEXT NOT NULL, " +
                    POSTER_IMAGE + " TEXT, " +
                    OVERVIEW + " TEXT, " +
                    RATE + " TEXT, " +
                    DATE + " TEXT);";

            db.execSQL(SQL_CREATE_MOVIE_TABLE);

        }


        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)

        {
            db.execSQL("DROP TABLE IF EXISTS " +TABLE_NAME);
            onCreate(db);

        }

    }
    public ArrayList<Movie> getData()
    {
        ArrayList<Movie>array=new ArrayList<>();
        String [] coulms={ID,DATE,POSTER_IMAGE,OVERVIEW,RATE,TITLE};
        Cursor cursor= database.query(TABLE_NAME,coulms,null,null,null,null,null,null);

        for (cursor.moveToFirst();!cursor.isAfterLast();cursor.moveToNext())
        {
            Movie movie=new Movie();
            movie.settitle(cursor.getString(cursor.getColumnIndex(TITLE)));
            movie.setDate( cursor.getString(cursor.getColumnIndex(DATE)));
            movie.setPoster_path(cursor.getString(cursor.getColumnIndex(POSTER_IMAGE)));
            movie.setoverview(cursor.getString(cursor.getColumnIndex(OVERVIEW)));
            movie.setId(cursor.getString(cursor.getColumnIndex(ID)));
            movie.setRate(cursor.getString(cursor.getColumnIndex(RATE)));
            array.add(movie);
        }
        return array;
    }
    public void OpenData()
    {
        Helper dBhelper=new Helper(context);
        database =dBhelper.getWritableDatabase();

    }
    public void Close()

    {
        database.close();
    }

    public  long  InsertFavoriteMovie(String title,String date,String poster,String overview,String rate,String id)

    {

        ContentValues contentValues = new ContentValues();
                contentValues.put(TITLE, title);
        contentValues.put(DATE,date);
        contentValues.put(POSTER_IMAGE, poster);
        contentValues.put(OVERVIEW, overview);
        contentValues.put(RATE,rate);
        contentValues.put(ID,id);
        long c= database.insert(TABLE_NAME, null, contentValues);
        return c;
    }


}

