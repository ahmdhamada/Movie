package com.example.hamadaa.mymovieapp;


import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import java.util.ArrayList;
import java.util.List;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.hamadaa.mymovieapp.Data.Movie;
import com.squareup.picasso.Picasso;

/**
 * Created by HaMaDaa on 8/14/2016.
 */
public class FlavorAdapter extends ArrayAdapter<Movie>{

   List<Movie> androidFlavors;
    private static final String LOG_TAG = FlavorAdapter.class.getSimpleName();
    public FlavorAdapter(Activity context, List<Movie> androidFlavors) {

        super(context, 0, androidFlavors);
        this.androidFlavors=androidFlavors;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(
                    R.layout.flavor, parent, false);
        }

        ImageView iconView = (ImageView) convertView.findViewById(R.id.flvimg);
        Log.e("e",androidFlavors.get(position).poster);
        Picasso.with(getContext())
                .load(androidFlavors.get(position).poster)
                .into(iconView);


        return convertView;
    }

}
