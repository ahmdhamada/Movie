package com.example.hamadaa.mymovieapp;


import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import com.example.hamadaa.mymovieapp.Data.Movie;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by HaMaDaa on 9/22/2016.
 */
public class MainFrag extends Fragment{

    private FlavorAdapter flavorAdapter;
    GridView gridView;
    List<Movie> list=new ArrayList<>();
    //ArrayList<Movie> desc=new ArrayList<String>();
    public MainFrag() {
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_main, container, false);
        gridView = (GridView) rootView.findViewById(R.id.flavors_grid);
        flavorAdapter=new FlavorAdapter(getActivity(),list);
        gridView.setAdapter(flavorAdapter);
        gridView.setOnItemClickListener(
                new AdapterView.OnItemClickListener()
                {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int position, long l)
                    {
                        String poster = flavorAdapter.getItem(position).poster;
                        String Date = flavorAdapter.getItem(position).Date;
                        String TITLE = flavorAdapter.getItem(position).Title;
                        String Overview = flavorAdapter.getItem(position).OverView;
                        String id = flavorAdapter.getItem(position).ID;
                        String rate = flavorAdapter.getItem(position).Rate;


                       Intent intent = new Intent(getActivity(), MovieDetails.class);
                        intent.putExtra("pos", poster);
                        intent.putExtra("date",Date);
                        intent.putExtra("title",TITLE);
                        intent.putExtra("overview",Overview);
                        intent.putExtra("ID",id);
                        intent.putExtra("rate",rate);
                        ((Callback) getActivity()).onItemSelected(intent);

                    }
                });

        return rootView;
    }
    public interface Callback {
        public void onItemSelected(Intent dateUri);
    }
    public  void fav(){
        MyDataBase database = new MyDataBase(getActivity());
        database.OpenData();
        ArrayList<Movie> movieDataArrayList = database.getData();
        ArrayList<String> m = new ArrayList<>();
        for (int i = 0; i < movieDataArrayList.size(); i++) {
            m.add(movieDataArrayList.get(i).getPoster_path());
        }
        this.list.clear();
        this.list =movieDataArrayList;
        flavorAdapter =new FlavorAdapter(getActivity(),list);
        gridView.setAdapter(flavorAdapter);
        database.Close();
    }

    @Override
    public void onStart() {
        super.onStart();
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String Type = sharedPrefs.getString(getString(R.string.pref_change_key), getString(R.string.pref_popular));
        if(Type.equals("Favourite"))
        {
            fav();
        }
        else{
            new FetchWeatherTask().execute(Type);
        }
    }

    ////////////////////////////////
    ////////////////////////
    public class FetchWeatherTask extends AsyncTask<String, Void, List<Movie>> {
        ArrayList<String> poster=new ArrayList<String>();
        ArrayList<String> date=new ArrayList<String>();
        ArrayList<String> Rate=new ArrayList<String>();
        ArrayList<String> desc1=new ArrayList<String>();
        private final String LOG_TAG = FetchWeatherTask.class.getSimpleName();
        private List<Movie> getWeatherDataFromJson(String forecastJsonStr)
                throws JSONException {
            JSONObject forecastJson = new JSONObject(forecastJsonStr);
            JSONArray weatherArray = forecastJson.getJSONArray("results");
            List<Movie> movies=new ArrayList<>();
            for (int i = 0; i < weatherArray.length(); i++) {
                JSONObject jsonObject = weatherArray.getJSONObject(i);
                movies.add(new Movie(jsonObject));


            }


            return movies;
        }

        @Override
        protected List<Movie> doInBackground(String... params) {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String forecastJsonStr = null;

            try {

                final String FORECAST_BASE_URL = "http://api.themoviedb.org/3/movie/" + params[0] + "?";
                final String QUERY_PARAM = "api_key";

                Uri builtUri = Uri.parse(FORECAST_BASE_URL).buildUpon()
                        .appendQueryParameter(QUERY_PARAM,"a858cd9b39d006380af13ad66e58987c")
                        .build();

                    URL url = new URL(builtUri.toString());

                Log.v(LOG_TAG, "Built URI: " + builtUri.toString());

                // Create the request to OpenWeatherMap, and open the connection
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    // Nothing to do.
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {


                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {

                    return null;
                }
                forecastJsonStr = buffer.toString();

                Log.v(LOG_TAG, "Forecast JSON String: " + forecastJsonStr);

            } catch (IOException e) {
                Log.e(LOG_TAG, "Error ", e);

                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e(LOG_TAG, "Error closing stream", e);
                    }
                }
            }
            try {
                return getWeatherDataFromJson(forecastJsonStr);
            } catch (JSONException e) {
                Log.e(LOG_TAG, e.getMessage(), e);
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(List<Movie> result) {

               flavorAdapter.clear();
                for(int i=0;i<result.size();i++)
                flavorAdapter.add(result.get(i));

        }
    }


}
