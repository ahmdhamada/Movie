package com.example.hamadaa.mymovieapp.Data;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by HaMaDaa on 9/22/2016.
 */
public class Movie {
    public String poster;
    public String Title;
    public String ID;
    public String Rate;
    public String OverView;
    public String Date;
public Movie(){

}
    public Movie(JSONObject jsonObject)throws JSONException{
        poster ="http://image.tmdb.org/t/p/w185"+jsonObject.getString("poster_path");
        Title=jsonObject.getString("original_title");
        ID=jsonObject.getString("id");
        Rate=jsonObject.getString("vote_average");
        Date=jsonObject.getString("release_date");
        OverView=jsonObject.getString("overview");

    }

    public String gettitle()
    {
        return Title;
    }

    public void settitle(String title)
    {
        this.Title = title;
    }

    public String getId()
    {
        return ID;
    }

    public void setId(String ID)
    {
        this.ID = ID;
    }

    public String getoverview()
    {
        return OverView;
    }

    public void setoverview(String description)
    {
        this.OverView = description;
    }

    public String getPoster_path()
    {
        return poster;
    }

    public void setPoster_path(String poster_path)
    {
        this.poster = poster_path;
    }

    public String getDate()
    {
        return Date;
    }

    public void setDate(String Date)
    {
        this.Date = Date;
    }

    public String getRate()
    {
        return Rate;
    }

    public void setRate(String rate)
    {
        this.Rate = rate;
    }


}
