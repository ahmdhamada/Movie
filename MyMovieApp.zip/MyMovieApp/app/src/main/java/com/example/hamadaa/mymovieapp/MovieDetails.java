package com.example.hamadaa.mymovieapp;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hamadaa.mymovieapp.Data.Movie;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by HaMaDaa on 9/22/2016.
 */
public class MovieDetails extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_details);
        if (savedInstanceState == null)
        {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.frag, new PlaceholderFragment())
                    .commit();
        }
    }
    public static  class PlaceholderFragment extends Fragment
    {
        String id;
        View view;
        ListView listView;
        ArrayAdapter<String> arrdata ;
        ArrayList url;
        String poster;
        String overview;
        String date ;
        String title;
        String rate ;
        String tested_id;
        @Override
        public View onCreateView(final LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState)
        {
            view=inflater.inflate(R.layout.movie_details, container, false);
            View mainview = inflater.inflate(R.layout.activity_main, container, false);
            url=new ArrayList<String>();
            listView = (ListView) view.findViewById(R.id.listView_Trailer);
            arrdata= new ArrayAdapter<String>(getActivity(),R.layout.trailertextview,R.id.textView,new ArrayList<String>());
            listView.setAdapter(arrdata);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    String link = (String) url.get(position);
                    Uri builtUri = Uri.parse("https://www.youtube.com/watch?v=" +link).buildUpon().build();
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(builtUri);
                    startActivity(intent);
                }
            });


            Intent intent = getActivity().getIntent();

            if (mainview.findViewById(R.id.movie_container) == null)
            {
                id = intent.getStringExtra("ID");
                poster = intent.getStringExtra("pos");
                overview = intent.getStringExtra("overview");
                date = intent.getStringExtra("date");
                title = intent.getStringExtra("title");
                rate = intent.getStringExtra("rate");
            }
            else
            {
                id = getArguments().getString("ID");
                poster = getArguments().getString("pos");
                overview = getArguments().getString("overview");
                date = getArguments().getString("date");
                title =getArguments().getString("title");
                rate = getArguments().getString("rate");
            }


            ImageView iconView = (ImageView) view.findViewById(R.id.detail_poster);
            Picasso.with(getContext())
                    .load(poster)
                    .into(iconView);
            TextView txt0=(TextView) view.findViewById(R.id.detail_title);
            txt0.setText(title);

            TextView txt1=(TextView) view.findViewById(R.id.detail_releaseDate);
            txt1.setText("Date:"+"\n"+date);

            TextView txt3=(TextView) view.findViewById(R.id.detail_rate);
            txt3.setText("Rate :"+rate+"/10");

            TextView txt2=(TextView) view.findViewById(R.id.detail_overview);
            txt2.setText("description:"+"\n"+overview);


            final ImageButton  imageButton=(ImageButton) view.findViewById(R.id.favorite_button);
            MyDataBase myDataBase =new MyDataBase(getActivity());
            myDataBase.OpenData();
            ArrayList<Movie> movieDataArrayList = myDataBase.getData();
            for (int i = 0; i < movieDataArrayList.size(); i++) {
                if(movieDataArrayList.get(i).getId().equals(id)){
                    tested_id =movieDataArrayList.get(i).getId();
                }
            }
            if(tested_id !=null){
                imageButton.setBackgroundResource(R.drawable.saved);
            }

            else{

                imageButton.setBackgroundResource(R.drawable.images);
                imageButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        MyDataBase myDataBase1 =new MyDataBase(getActivity());
                        myDataBase1.OpenData();
                        myDataBase1.InsertFavoriteMovie(title,date,poster,overview,rate,id);
                        myDataBase1.Close();
                        Toast.makeText(getActivity(),"Add to your favourite",Toast.LENGTH_SHORT).show();
                        imageButton.setBackgroundResource(R.drawable.saved);
                    }
                });


            }

            return  view;
        }

/////////////////////////////////////////////////////////////////////////
@Override
public void onStart() {
    super.onStart();
    new FetchWeatherTask1().execute(id);
    new FetchWeatherTask2().execute(id);
}

    /////////////////////////////////////////////////
    public class FetchWeatherTask1 extends AsyncTask<String, Void, String> {
        String author;
        String content;
        private final String LOG_TAG = FetchWeatherTask1.class.getSimpleName();

        private String getWeatherDataFromJson(String forecastJsonStr)
                throws JSONException {
            JSONObject forecastJson = new JSONObject(forecastJsonStr);
            JSONArray weatherArray = forecastJson.getJSONArray("results");


            for (int i = 0; i < weatherArray.length(); i++) {
                JSONObject dayForecast = weatherArray.getJSONObject(i);
                author = dayForecast.getString("author");
                content = dayForecast.getString("content");
            }
            return author;
        }

        @Override
        protected String doInBackground(String... params) {

            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            // Will contain the raw JSON response as a string.
            String forecastJsonStr = null;
            try {
                // Construct the URL for the OpenWeatherMap query
                // Possible parameters are available at OWM's forecast API page, at
                // http://openweathermap.org/API#forecast
                final String FORECAST_BASE_URL = "http://api.themoviedb.org/3/movie/?";
                final String DAYS_PARAM = "api_key";

                Uri builtUri = Uri.parse(FORECAST_BASE_URL).buildUpon()
                        .appendPath(id)
                        .appendPath("reviews")
                        .appendQueryParameter(DAYS_PARAM, "a858cd9b39d006380af13ad66e58987c")
                        .build();

                URL url = new URL(builtUri.toString());

                Log.v(LOG_TAG, "Built URI: " + builtUri.toString());


                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    // Nothing to do.
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }

                if (buffer.length() == 0) {

                    return null;
                }

                forecastJsonStr = buffer.toString();


                Log.v(LOG_TAG, "Forecast JSON String: " + forecastJsonStr);

            } catch (IOException e) {
                Log.e(LOG_TAG, "Error ", e);

                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final IOException e) {
                        Log.e(LOG_TAG, "Error closing stream", e);
                    }
                }
            }
            try {
                return getWeatherDataFromJson(forecastJsonStr);
            } catch (JSONException e) {
                Log.e(LOG_TAG, e.getMessage(), e);
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            TextView authertext=(TextView) view.findViewById(R.id.auth);
            TextView b=(TextView) view.findViewById(R.id.con);
            authertext.setText("Author:-"+"\n"+author);
            b.setText("Content:-"+"\n"+content);
        }
    }
///////////////////////////////////////////
/////////////////////////////////////////////////
public class FetchWeatherTask2 extends AsyncTask<String, Void, ArrayList<String>> {
    private final String LOG_TAG = FetchWeatherTask2.class.getSimpleName();

    private ArrayList<String> getWeatherDataFromJson(String forecastJsonStr)
            throws JSONException {
        JSONObject forecastJson = new JSONObject(forecastJsonStr);
        JSONArray weatherArray = forecastJson.getJSONArray("results");
        ArrayList<String> rr = new ArrayList<>();
        for (int i = 0; i < weatherArray.length(); i++) {
            JSONObject dayForecast = weatherArray.getJSONObject(i);
            String s = dayForecast.getString("key");
            rr.add(s);
        }
        return rr;
    }

    @Override
    protected ArrayList<String> doInBackground(String... params) {

        // If there's no zip code, there's nothing to look up. Verify params.
        // if (params.length == 0) return null;

        // These two need to be declared outside the try/catch
        // so that they can be closed in the finally block.
        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;
        // Will contain the raw JSON response as a string.
        String forecastJsonStr = null;


        try {

            final String FORECAST_BASE_URL = "http://api.themoviedb.org/3/movie/?";
            final String DAYS_PARAM = "api_key";

            Uri builtUri = Uri.parse(FORECAST_BASE_URL).buildUpon()
                    .appendPath(id)
                    .appendPath("videos")
                    .appendQueryParameter(DAYS_PARAM, "a858cd9b39d006380af13ad66e58987c")
                    .build();

            URL url = new URL(builtUri.toString());

            Log.v(LOG_TAG, "Built URI: " + builtUri.toString());

            // Create the request to OpenWeatherMap, and open the connection
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            // Read the input stream into a String
            InputStream inputStream = urlConnection.getInputStream();
            StringBuffer buffer = new StringBuffer();
            if (inputStream == null) {
                // Nothing to do.
                return null;
            }
            reader = new BufferedReader(new InputStreamReader(inputStream));

            String line;
            while ((line = reader.readLine()) != null) {
                // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                // But it does make debugging a *lot* easier if you print out the completed
                // buffer for debugging.
                buffer.append(line + "\n");
            }

            if (buffer.length() == 0) {
                // Stream was empty.  No point in parsing.
                return null;
            }

            forecastJsonStr = buffer.toString();


            Log.v(LOG_TAG, "Forecast JSON String: " + forecastJsonStr);

        } catch (IOException e) {
            Log.e(LOG_TAG, "Error ", e);
            return null;
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e) {
                    Log.e(LOG_TAG, "Error closing stream", e);
                }
            }
        }
        try {
            return getWeatherDataFromJson(forecastJsonStr);
        } catch (JSONException e) {
            Log.e(LOG_TAG, e.getMessage(), e);
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(ArrayList<String> result) {
        arrdata.clear();
        url.clear();
        String s1="Trailer";
        ArrayList <String>  s=new ArrayList<String>();
        if (result != null) {
            for(String ur :result){
                url.add(ur);
                arrdata.add(s1);
            }
        }
    }
}
    }
}
